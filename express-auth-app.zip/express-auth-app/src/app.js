const express = require('express');
const dotenv = require('dotenv');
dotenv.config();  // Load environment variables from .env
const routes = require('./route');  // Import the routes

const app = express();

// Middleware to parse JSON requests
app.use(express.json());

// Use the routes from route.js
app.use('/api', routes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
