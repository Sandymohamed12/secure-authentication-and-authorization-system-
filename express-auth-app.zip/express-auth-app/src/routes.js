const express = require('express');
const authenticateJWT = require('./middlewares/authMiddleware');  // Import JWT authentication middleware
const router = express.Router();

// Public route: accessible by everyone
router.get('/public', (req, res) => {
    res.json({ message: 'This is a public route. Anyone can access it.' });
});

// Protected route: accessible only by authenticated users
router.get('/protected', authenticateJWT, (req, res) => {
    res.json({
        message: 'This is a protected route.',
        user: req.user // The user information added by the JWT middleware
    });
});

// Moderator-only route: accessible by users with the 'moderator' role
router.get('/moderator', authenticateJWT, (req, res) => {
    if (req.user.role !== 'moderator' && req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Access denied. You are not a moderator.' });
    }
    res.json({ message: 'This is a moderator route.' });
});

// Admin-only route: accessible by users with the 'admin' role
router.get('/admin', authenticateJWT, (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Access denied. You are not an admin.' });
    }
    res.json({ message: 'This is an admin route.' });
});

module.exports = router;
